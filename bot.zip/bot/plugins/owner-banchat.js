let handler = async (m) => {
global.db.data.chats[m.chat].isBanned = true
m.reply('*🔥 Este Chat fue Baneado con Éxito 🔥*\n\n*—◉ El Bot no Reaccionará a Ningún Comando Hasta Desbanear este Chat*')
}
handler.help = ['banchat']
handler.tags = ['owner']
handler.command = /^banchat$/i
handler.rowner = true
export default handler
