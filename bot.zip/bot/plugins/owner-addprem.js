let handler = async (m, { conn, text }) => {
let who
if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text
else who = m.chat
if (!who) throw `*🔥 Ingresa el @𝚝𝚊𝚐 de la Persona que Desee Agregar a los Usuarios Premium 🔥*`
if (global.prems.includes(who.split`@`[0])) throw '*🍒 El Usuario Ingresado ya es Usuario Premium 🍒*'
global.prems.push(`${who.split`@`[0]}`)
let user = global.db.data.users[who]
user.premium = true
let textprem = `*👤 @${who.split`@`[0]} Ahora es un Usuario Premium, No Tendrá Limites al Usar el Bot*`
m.reply(textprem, null, { mentions: conn.parseMention(textprem) })
}
handler.help = ['addprem <@user>']
handler.tags = ['owner']
handler.command = /^(add|\+)prem$/i
handler.group = true
handler.rowner = true
export default handler
