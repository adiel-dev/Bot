let handler = async (m, { conn, text }) => {

let [nomor, pesan, jumlah] = text.split('|')
if (!nomor) throw '*🔥 Por Favor Ingrese el Número al Cual se Enviará el Spam de Mensajes 🔥*\n*Uso Correcto:*\n*—◉ #spamwa numero|texto|cantidad*\n*Ejemplo:*\n*—◉ #spamwa 5219999999999|responde :v|25*'
if (!pesan) throw '*🍒 Por Favor Ingrese el Mensaje Para Hacer e Spam 🍒*\n*Uso Correcto:*\n*—◉ #spamwa numero|texto|cantidad*\n*Ejemplo:*\n*—◉ #spamwa 5219999999999|responde :v|25*'
if (jumlah && isNaN(jumlah)) throw '*🔒 La Cantidad debe ser un Número 🔒*\n*Uso Correcto:*\n*—◉ #spamwa numero|texto|cantidad*\n*Ejemplo:*\n*—◉ #spamwa 5219999999999|responde :v|25*'

let fixedNumber = nomor.replace(/[-+<>@]/g, '').replace(/ +/g, '').replace(/^[0]/g, '62') + '@s.whatsapp.net'
let fixedJumlah = jumlah ? jumlah * 1 : 10
if (fixedJumlah > 50) throw '*🔒 ¡Demasiados Mensajes! 🔒 La Cantidad debe ser Menor a 50'
await m.reply(`*🍀 El Spam de Mensajes al Número ${nomor} Fue Realizado con Éxito 🍀*\n*Cantidad :*\n*—◉ ${fixedJumlah} Veces!*`)
for (let i = fixedJumlah; i > 1; i--) {
if (i !== 0) conn.reply(fixedNumber, pesan.trim(), m)
}}
handler.help = ['spamwa <number>|<mesage>|<no of messages>']
handler.tags = ['General']
handler.command = /^spam(wa)?$/i
handler.group = false
handler.premium = false
handler.private = true
handler.limit = true
export default handler
