let handler = async (m, { conn, text }) => {
let who
if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text
else who = m.chat
if (!who) throw `*🔥 Ingresa el @𝚝𝚊𝚐 de la Persona que Desee Eliminar de los Usuarios Premium 🔥*`
if (!global.prems.includes(who.split`@`[0])) throw '*⚔️ El Usuario Ingresado No es Usuario Premium ⚔️*'
let index = global.prems.findIndex(v => (v.replace(/[^0-9]/g, '') + '@s.whatsapp.net') === (who.replace(/[^0-9]/g, '') + '@s.whatsapp.net'))
global.prems.splice(index, 1)
let user = db.data.users[who]
user.premium = false
let textdelprem = `*⚔️ @${who.split`@`[0]} Ahora ya no Forma Parte de los Usuarios Premium ⚔️*`
m.reply(textdelprem, null, { mentions: conn.parseMention(textdelprem) })
}
handler.help = ['delprem <@user>']
handler.tags = ['owner']
handler.command = /^(remove|-|del)prem$/i
handler.group = true
handler.rowner = true
export default handler
