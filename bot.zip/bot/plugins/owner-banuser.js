let handler = async (m, { conn, participants, usedPrefix, command }) => {
let BANtext = `🔥 Etiquete a una Persona o Responda a Un Mensaje Enviado por el Usuario que Desee Banear 🔥\n\n*—◉ Ejemplo:*\n*${usedPrefix + command} @${global.suittag}*`
if (!m.mentionedJid[0] && !m.quoted) return m.reply(BANtext, m.chat, { mentions: conn.parseMention(BANtext)})
let who
if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender
else who = m.chat
let users = global.db.data.users
users[who].banned = true
m.reply('*🍒 El Usuario fue Baneado con Éxito 🍒*\n*—◉ El Usuario no Podrá Usar el Bot Hasta que sea Desbaneado*')    }
handler.command = /^banuser$/i
handler.rowner = true
export default handler
