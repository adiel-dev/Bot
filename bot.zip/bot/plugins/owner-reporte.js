let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `*🔒 Ingrese un Reporte 🔒*\n\n*Ejemplo:*\n*${usedPrefix + command} el comando ${usedPrefix}play no manda nada*`
if (text.length < 10) throw `*🩸 El Reporte Debe Ser Mínimo 10 Caracteres 🩸*`
if (text.length > 1000) throw `*🩸 El Reporte Debe Ser Máximo 1000 Caracteres 🩸*`
let teks = `*❒═════[REPORTE]═════❒*\n*┬*\n*├❧ Número:* wa.me/${m.sender.split`@`[0]}\n*┴*\n*┬*\n*├❧ Mensaje:* ${text}\n*┴*`
conn.reply('17059900962@s.whatsapp.net', m.quoted ? teks + m.quoted.text : teks, null, { contextInfo: { mentionedJid: [m.sender] }})
conn.reply('17059900962@s.whatsapp.net', m.quoted ? teks + m.quoted.text : teks, null, { contextInfo: { mentionedJid: [m.sender] }})
m.reply(`*🍒 Reporte Enviado Con Éxito al Creador del Bot, Su Reporte Será Antendido lo Antes Posible, Si es Falso o Broma Sólo se Ignorará 🍒*`)
}
handler.help = ['reporte', 'request'].map(v => v + ' <teks>')
handler.tags = ['info']
handler.command = /^(report|request|reporte|bugs|bug|report-owner|reportes)$/i
export default handler
