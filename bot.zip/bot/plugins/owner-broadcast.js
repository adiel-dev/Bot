import fs from 'fs'
let handler = async (m, { conn, text } ) => {  
let chatsall = Object.entries(conn.chats).filter(([_, chat]) => chat.isChats).map(v => v[0])
let cc = text ? m : m.quoted ? await m.getQuotedObj() : false || m
let teks = text ? text : cc.text
for (let id of chatsall) { 
conn.sendButton(id, `*╔══❰ COMUNICADO ❱══╗*\n*║*\n*╠❧* ${text}\n*║*\n*╚══════════════╝*`, 'ESTE ES UN COMUNICADO ESPECIAL\n' + wm, fs.readFileSync('./src/avatar_contact.png'), [['🤖 Owner 🤖', '.owner'],['💰 Donar 💰', '.donasi']], false, { 
contextInfo: { externalAdReply: {
title: 'Comunicado Oficial a Todos los Chats',
body: 'Netfree - Bot', 
sourceUrl: `https://github.com/adiel-dev/bot`, 
thumbnail: fs.readFileSync('./Menu2.jpg') }}})}
m.reply(`*🍒 Mensaje Enviado a Todos los Chats 🍒*\n\n*Es Posible que Tenga Fallas este Comando y No se Envíe a Todos los Chats, Disculpe por el Momento*`)
}
handler.help = ['broadcast', 'bc'].map(v => v + ' <teks>')
handler.tags = ['owner']
handler.command = /^(broadcast|bc)$/i
handler.rowner = true
export default handler
