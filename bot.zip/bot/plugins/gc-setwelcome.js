let handler = async (m, { conn, text, isROwner, isOwner }) => {
if (text) {
global.db.data.chats[m.chat].sWelcome = text
m.reply('*🍒 Mensaje de Bienvenida Configurado Correctamente Para Este Grupo 🍒*')
} else throw `*🩸 Ingrese el Mensaje de Bienvenida que Desee Agregar 🩸, Use:*\n*- @user (mención)*\n*- @group (nombre de grupo)*\n*- @desc (description de grupo)*`
}
handler.help = ['setwelcome <text>']
handler.tags = ['group']
handler.command = ['setwelcome'] 
handler.admin = true
export default handler
