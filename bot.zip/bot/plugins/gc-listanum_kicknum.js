/*              *****
*/

let handler = async (m, { conn, args, groupMetadata, participants, usedPrefix, command, isBotAdmin, isSuperAdmin }) => {
if (!args[0]) return m.reply(`*🩸 Ingresa el Prefijo de un País Para Buscar Números en Este Grupo de ese País 🩸, Ejemplo: ${usedPrefix + command} 52*`) 
if (isNaN(args[0])) return m.reply(`*🩸 Ingresa el Prefijo de un País Para Buscar Números en Este Grupo de ese País 🩸, Ejemplo: ${usedPrefix + command} 52*`) 
let lol = args[0].replace(/[+]/g, '')
let ps = participants.map(u => u.id).filter(v => v !== conn.user.jid && v.startsWith(lol || lol)) 
let bot = global.db.data.settings[conn.user.jid] || {}
if (ps == '') return m.reply(`*⚔️ En este Grupo no hay Ningún Número con el Prefijo⚔️ +${lol}*`)
let numeros = ps.map(v=> '⭔ @' + v.replace(/@.+/, ''))
const delay = time => new Promise(res=>setTimeout(res,time));
switch (command) {
case "listanum": 
conn.reply(m.chat, `*Lista de Números con el Prefijo +${lol} que Están en este Grupo:*\n\n` + numeros.join`\n`, m, { mentions: ps })
break   
case "kicknum":  
if (!bot.restrict) return m.reply('*⚔️ El Propietario del Bot No Tiene Habilitado las Restricciones (#enable restrict) Contacte con el Para que lo Habilite ⚔️*') 
if (!isBotAdmin) return m.reply('*⚔️ El Bot no es Admin, No Puede Exterminar a las Personas ⚔️*')          
conn.reply(m.chat, `*🩸 Iniciando Eliminación de Números con el Prefijo 🩸 +${lol}, Cada 10 Segundos se Eliminará a un Usuario*`, m)            
let ownerGroup = m.chat.split`-`[0] + '@s.whatsapp.net'
let users = participants.map(u => u.id).filter(v => v !== conn.user.jid && v.startsWith(lol || lol))
for (let user of users) {
let error = `@${user.split("@")[0]} Ya ha Sido Eliminado o Abandonado al Grupo*`    
if (user !== ownerGroup + '@s.whatsapp.net' && user !== global.conn.user.jid && user !== global.owner + '@s.whatsapp.net' && user.startsWith(lol || lol) && user !== isSuperAdmin && isBotAdmin && bot.restrict) { 
await delay(2000)    
let responseb = await conn.groupParticipantsUpdate(m.chat, [user], 'remove')
if (responseb[0].status === "404") m.reply(error, m.chat, { mentions: conn.parseMention(error)})  
await delay(10000)
} else return m.reply('*⚔️ Error ⚔️*')}
break            
}}
handler.command = /^(listanum|kicknum)$/i
handler.group = handler.botAdmin = handler.admin = true
handler.fail = null
export default handler
