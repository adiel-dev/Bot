import fetch from 'node-fetch'
let handler = async (m, {command, conn, text}) => {
if (!text) throw `🔒 Nombre de la Canción Faltante 🔒 Por Favor Ingrese el Comando mas el Nombre/Título, Enlace de una Canción o Video de Youtube\n\n*—◉ Ejemplo:\n#play.1 Nombre - título*`
try {
let res = await fetch(`https://api.lolhuman.xyz/api/ytplay2?apikey=${lolkeysapi}&query=${text}`)
if (command == 'play.1') {
conn.reply(m.chat, `*☁️ Se esta Procesando su Audio, Por Favor Espere ☁️*`, m)  
let json = await res.json()
let aa = conn.sendMessage(m.chat, { audio: { url: json.result.audio }, fileName: `error.mp3`, mimetype: 'audio/mp4' }, { quoted: m })
if (!aa) return conn.sendFile(m.chat, json.result.audio, 'error.mp3', null, m, false, { mimetype: 'audio/mp4' })}
if (command == 'play.2') {
conn.reply(m.chat, `*☁️ Se está Procesando su Video, Por Favor Espere ☁️*`, m)
let json = await res.json()
conn.sendFile(m.chat, json.result.video, 'error.mp4', `NetFree - Bot`, m)}
} catch (e) {
m.reply('*🔒 Por Favor Vuelva a Intentarlo 🔒*')
}}
handler.help = ['play.1' , 'play.2'].map(v => v + ' <texto>')
handler.tags = ['downloader']
handler.command = ['play.1', 'play.2']
export default handler
